<script setup lang="ts">
import { Check, ChevronsUpDown, Search, Plus, BadgeCheck, X, ListFilter, File, Loader2 } from 'lucide-vue-next'
import { onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from "#app";
import { useDocStore } from '@/lib/docStore'

// Import components from the custom library
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from '@/components/ui/command'
import {
  Badge
} from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Separator } from '@/components/ui/separator'
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarRail,
  SidebarTrigger,
} from '@/components/ui/sidebar'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import Spinner from "~/components/Spinner.vue";
import SearchButton from "~/components/layout/SearchButton.vue";
import HashBreadcrumb from "~/components/layout/HashBreadcrumb.vue";

const config = useConfig();
const route = useRoute();
const router = useRouter();
const store = useDocStore();

onMounted(() => {
  store.loadStored();
})

watch(() => store.selectedDocUrl, (newUrl) => {
  if (newUrl) store.loadDoc(newUrl)
})

type Pair = {
  name: string;
  count: number;
}
const countedGroups = computed(() => {
  const group = store.selectedDoc[store.selectedGroup];
  const data: Pair[] = [
    {
      name: "methods",
      count: Object.values(group).length
    },
    {
      name: "delegates",
      count: Object.values(group).length
    },
    {
      name: "enumerators",
      count: Object.values(group).length
    },
  ];
  return data;
});
const filteredGroups = computed(() => store.selectedDoc[store.selectedGroup]);
const isRefreshing = computed(() => store.isRefreshing[store.selectedDocUrl]);

store.onRouteChange(router.currentRoute.value.hash);
watch(() => route.hash, (newHash, oldHash) => {
  store.onRouteChange(newHash);
});

const handleInput = (event: any) => {
  router.push(`#/search/${event.target.value}`);
};

const selectRow = (link?: string) => {
  router.push(`#/${store.selectedGroup}/${link}`);
}

const inputUrl = ref('')
const errorMessage = ref('');

const isHttpValid = (url: string) => {
  try {
    const newUrl = new URL(url);
    return newUrl.protocol === 'http:' || newUrl.protocol === 'https:';
  } catch (err) {
    return false;
  }
}

const addUrl = () => {
  const url = inputUrl.value.trim();
  if (isHttpValid(url)) {
    store.addDocUrl(url);
    closeDialog();
  } else {
    errorMessage.value = "Invalid URL";
  }
}

const closeDialog = () => {
  inputUrl.value = ''
}

</script>

<template>
  <SidebarProvider>
    <Sidebar>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SearchButton :title="store.selectedDocUrl" />
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <div class="flex-1">
          <template v-if="isRefreshing">
            <Spinner />
          </template>
          <nav class="grid items-start px-2 text-sm font-medium lg:px-4">
            <ul v-for="(data, group) in store.selectedDoc" :key="group">
              <a
                  :href="`#/${group}`"
                  class="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                  v-bind:class="{ 'bg-muted' : group === store.selectedGroup }"
                  v-if="Object.values(data.methods).length > 0"
              >
                {{ group }}
                <Badge class="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full">
                  {{ Object.values(data.methods).length + Object.values(data.enumerators).length + Object.values(data.delegates).length }}
                </Badge>
              </a>
            </ul>
          </nav>
        </div>
      </SidebarContent>
      <SidebarRail />
    </Sidebar>
    <SidebarInset>
      <header class="flex h-16 shrink-0 items-center gap-2 border-b px-4">
        <SidebarTrigger class="-ml-1" />
        <Separator orientation="vertical" class="mr-2 h-4" />
        <HashBreadcrumb :fragments="store.fragments"/>
        <div class="flex flex-1 justify-end gap-2">
          <!--<LayoutSearchButton v-if="!config.search.inAside && config.search.style === 'input'" />-->
          <div class="flex">
            <!--<LayoutSearchButton v-if="!config.search.inAside && config.search.style === 'button'" />-->
            <ThemePopover v-if="config.theme.customizable" />
            <DarkModeToggle v-if="config.header.darkModeToggle" />
            <NuxtLink
                v-for="(link, i) in config.header.links"
                :key="i"
                :to="link?.to"
                :target="link?.target"
            >
              <Button variant="ghost" size="icon" class="flex gap-2">
                <Icon v-if="link?.icon" :name="link.icon" :size="18" />
              </Button>
            </NuxtLink>
          </div>
        </div>
      </header>
      <div class="flex flex-1 flex-col gap-4 p-4">
        <div class="grid gap-6">
          <form class="relative" @submit.prevent>
            <Input placeholder="Search Query" class="pl-10" @input="handleInput" v-model="store.querySearch" />
            <span class="absolute start-0 inset-y-0 flex items-center justify-center px-2">
              <Search class="size-6 text-muted-foreground" />
            </span>
          </form>
        </div>
        <template v-if="isRefreshing">
         <Spinner />
        </template>
        <template v-if="store.searchMode">
        </template>
<!--        <template v-else-if="store.foundMethod">
          <MethodContent :method="store.foundMethod" />
        </template>-->
        <template v-else-if="store.selectedDoc && filteredGroups">
          <Tabs default-value="methods">
            <TabsPanel :tabs="countedGroups"/>
            <TabsContent value="methods">
              <ReferenceTable title="Methods" :elements="Object.values(filteredGroups.methods)" :onclick="selectRow" />
            </TabsContent>
            <TabsContent value="delegates">
              <ReferenceTable title="Delegates" :elements="Object.values(filteredGroups.delegates)" :onclick="selectRow" />
            </TabsContent>
            <TabsContent value="enumerators">
              <ReferenceTable title="Enumerators" :elements="Object.values(filteredGroups.enumerators)" :onclick="selectRow" />
            </TabsContent>
          </Tabs>
        </template>
        <template v-else>
          <PlugifyIntro/>
        </template>
      </div>
      <Footer/>
    </SidebarInset>
  </SidebarProvider>
</template>