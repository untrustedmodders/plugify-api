<template>
  <template v-if="enable">
    <Button
      v-if="style === 'input'"
      variant="outline"
      class="mb-4 h-8 w-full self-center rounded-md pr-1.5 font-normal text-muted-foreground hover:text-accent-foreground"
      @click="isOpen = true"
    >
      <span class="mr-auto overflow-hidden">
        {{ title.length > 0 ? title : placeholder }}
      </span>
      <Kbd class="ml-auto hidden md:block">
        <span class="text-xs">⌘</span>K
      </Kbd>
    </Button>
    <Button
      v-else
      variant="ghost"
      size="icon"
      @click="isOpen = true"
    >
      <Icon name="lucide:search" size="16" />

    </Button>
  </template>

  <LayoutSearchDialog v-model:open="isOpen" />
</template>

<script setup lang="ts">
const isOpen = ref(false);
const { enable, /*inAside,*/ style, placeholder } = useConfig().value.search;
const props = defineProps<{ title: string }>();
</script>
